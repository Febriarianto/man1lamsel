<!doctype html>
<html lang="id">
<head>
    <?php ($adminLogo=\App\Models\Setting::mediaUrl($siteSettings['site_logo']??null,asset('images/logo.svg'))); ?>
    <?php ($adminFavicon=\App\Models\Setting::mediaUrl($siteSettings['site_favicon']??null,asset('images/logo.svg'))); ?>
    <?php ($applyAdminTheme=($siteSettings['theme_apply_admin']??'1')==='1'); ?>
    <?php ($adminPrimary=\App\Models\Setting::normalizeHex($applyAdminTheme?($siteSettings['theme_primary']??'#0877C9'):'#0877C9')); ?>
    <?php ($adminPrimaryDark=\App\Models\Setting::normalizeHex($applyAdminTheme?($siteSettings['theme_primary_dark']??'#045A9D'):'#045A9D','#045A9D')); ?>
    <?php ($adminAccent=\App\Models\Setting::normalizeHex($applyAdminTheme?($siteSettings['theme_accent']??'#F4CD00'):'#F4CD00','#F4CD00')); ?>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title','Dashboard'); ?> — CMS <?php echo e($siteSettings['site_name'] ?? 'MAN 1 Lampung Selatan'); ?></title>
    <link rel="icon" href="<?php echo e($adminFavicon); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/admin.css')); ?>" rel="stylesheet">
    <style>:root{--brand:<?php echo e($adminPrimary); ?>;--brand-rgb:<?php echo e(\App\Models\Setting::hexToRgb($adminPrimary)); ?>;--brand-dark:<?php echo e($adminPrimaryDark); ?>;--brand-dark-rgb:<?php echo e(\App\Models\Setting::hexToRgb($adminPrimaryDark,'#045A9D')); ?>;--accent:<?php echo e($adminAccent); ?>;--accent-rgb:<?php echo e(\App\Models\Setting::hexToRgb($adminAccent,'#F4CD00')); ?>;}</style>
</head>
<body>
<div class="admin-shell">
    <aside class="sidebar" id="sidebar">
        <a class="sidebar-brand" href="<?php echo e(route('admin.dashboard')); ?>"><img src="<?php echo e($adminLogo); ?>" alt="Logo"><span><?php echo e($siteSettings['site_name'] ?? 'MAN 1 LS'); ?><small><?php echo e(auth()->user()->isAdmin()?'Content Management':'Ruang Penulis'); ?></small></span></a>
        <nav class="sidebar-nav">
            <span class="nav-label">UTAMA</span>
            <a class="<?php echo e(request()->routeIs('admin.dashboard')?'active':''); ?>" href="<?php echo e(route('admin.dashboard')); ?>"><i class="bi bi-grid-1x2"></i> Dashboard</a>
            <span class="nav-label"><?php echo e(auth()->user()->isAdmin()?'KONTEN':'PENULIS'); ?></span>
            <a class="<?php echo e(request()->routeIs('admin.posts.*')?'active':''); ?>" href="<?php echo e(route('admin.posts.index')); ?>"><i class="bi bi-newspaper"></i> <?php echo e(auth()->user()->isAdmin()?'Berita & Artikel':'Artikel Saya'); ?></a>
            <?php if(auth()->user()->isAdmin()): ?>
            <a class="<?php echo e(request()->routeIs('admin.pages.*')?'active':''); ?>" href="<?php echo e(route('admin.pages.index')); ?>"><i class="bi bi-file-earmark-text"></i> Halaman Profil</a>
            <a class="<?php echo e(request()->routeIs('admin.staff.*')?'active':''); ?>" href="<?php echo e(route('admin.staff.index')); ?>"><i class="bi bi-people"></i> Guru & Staf</a>
            <a class="<?php echo e(request()->routeIs('admin.galleries.*')?'active':''); ?>" href="<?php echo e(route('admin.galleries.index')); ?>"><i class="bi bi-images"></i> Galeri</a>
            <a class="<?php echo e(request()->routeIs('admin.infographics.*')?'active':''); ?>" href="<?php echo e(route('admin.infographics.index')); ?>"><i class="bi bi-file-earmark-bar-graph"></i> Infografis</a>
            <a class="<?php echo e(request()->routeIs('admin.events.*')?'active':''); ?>" href="<?php echo e(route('admin.events.index')); ?>"><i class="bi bi-calendar-event"></i> Agenda</a>
            <span class="nav-label">TAMPILAN</span>
            <a class="<?php echo e(request()->routeIs('admin.menus.*')?'active':''); ?>" href="<?php echo e(route('admin.menus.index')); ?>"><i class="bi bi-list-nested"></i> Menu Navbar</a>
            <a class="<?php echo e(request()->routeIs('admin.banners.*')?'active':''); ?>" href="<?php echo e(route('admin.banners.index')); ?>"><i class="bi bi-window-stack"></i> Banner Utama</a>
            <a class="<?php echo e(request()->routeIs('admin.links.*')?'active':''); ?>" href="<?php echo e(route('admin.links.index')); ?>"><i class="bi bi-link-45deg"></i> Tautan Layanan</a>
            <a class="<?php echo e(request()->routeIs('admin.settings.*')?'active':''); ?>" href="<?php echo e(route('admin.settings.edit')); ?>"><i class="bi bi-gear"></i> Pengaturan, Tema & SEO</a>
            <span class="nav-label">PENGGUNA & LAYANAN</span>
            <a class="<?php echo e(request()->routeIs('admin.users.*')?'active':''); ?>" href="<?php echo e(route('admin.users.index')); ?>"><i class="bi bi-person-badge"></i> Pengguna & Penulis</a>
            <a class="<?php echo e(request()->routeIs('admin.messages.*')?'active':''); ?>" href="<?php echo e(route('admin.messages.index')); ?>"><i class="bi bi-envelope"></i> Pesan Masuk <?php ($unread=\App\Models\ContactMessage::whereNull('read_at')->count()); ?><?php if($unread): ?><span class="badge text-bg-warning ms-auto"><?php echo e($unread); ?></span><?php endif; ?></a>
            <?php endif; ?>
        </nav>
    </aside>
    <main class="admin-main">
        <header class="admin-topbar"><button class="btn sidebar-toggle" id="sidebarToggle"><i class="bi bi-list"></i></button><div class="ms-auto d-flex align-items-center gap-3"><a class="btn btn-light btn-sm" target="_blank" href="<?php echo e(route('home')); ?>"><i class="bi bi-box-arrow-up-right me-1"></i> Lihat Website</a><div class="dropdown"><button class="btn user-menu dropdown-toggle" data-bs-toggle="dropdown"><span class="avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></span><span class="d-none d-md-inline"><?php echo e(auth()->user()->name); ?></span></button><ul class="dropdown-menu dropdown-menu-end"><li><div class="px-3 py-2"><small class="text-secondary d-block"><?php echo e(auth()->user()->isAdmin()?'Administrator':'Penulis Artikel'); ?></small><?php if(auth()->user()->unit_name): ?><small><?php echo e(auth()->user()->unit_name); ?></small><?php endif; ?></div></li><li><hr class="dropdown-divider"></li><li><a class="dropdown-item" href="<?php echo e(route('admin.account.edit')); ?>"><i class="bi bi-person-gear me-2"></i>Akun Saya</a></li><li><hr class="dropdown-divider"></li><li><form method="post" action="<?php echo e(route('admin.logout')); ?>"><?php echo csrf_field(); ?><button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right me-2"></i>Keluar</button></form></li></ul></div></div></header>
        <div class="admin-content">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4"><div><h1 class="page-title"><?php echo $__env->yieldContent('page_title','Dashboard'); ?></h1><p class="page-subtitle mb-0"><?php echo $__env->yieldContent('page_subtitle','Kelola portal MAN 1 Lampung Selatan'); ?></p></div><?php echo $__env->yieldContent('page_actions'); ?></div>
            <?php if(session('success')): ?><div class="alert alert-success alert-dismissible fade show"><?php echo e(session('success')); ?><button class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
            <?php if(session('error')): ?><div class="alert alert-danger"><?php echo e(session('error')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?><div class="alert alert-danger"><strong>Periksa kembali data berikut:</strong><ul class="mb-0 mt-2"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
<script>document.getElementById('sidebarToggle')?.addEventListener('click',()=>document.body.classList.toggle('sidebar-open'));document.querySelectorAll('[data-confirm]').forEach(el=>el.addEventListener('click',e=>{if(!confirm(el.dataset.confirm||'Yakin?'))e.preventDefault()}));</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body></html>
<?php /**PATH D:\tester\MAN1Lamsel\resources\views/admin/layout.blade.php ENDPATH**/ ?>