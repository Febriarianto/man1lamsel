<li class="menu-item" data-id="<?php echo e($menu->id); ?>">
    <div class="menu-row">
        <span class="drag-handle" title="Geser untuk mengubah urutan"><i class="bi bi-grip-vertical"></i></span>
        <span class="menu-icon"><i class="bi <?php echo e($menu->icon ?: 'bi-link-45deg'); ?>"></i></span>
        <div class="menu-info">
            <strong><?php echo e($menu->title); ?></strong>
            <small><?php echo e($menu->url ?: 'Menu induk/tanpa tautan'); ?></small>
        </div>
        <span class="status-dot <?php echo e($menu->active ? 'published' : 'draft'); ?>"><?php echo e($menu->active ? 'Aktif' : 'Nonaktif'); ?></span>
        <div class="table-actions">
            <a href="<?php echo e(route('admin.menus.edit', $menu)); ?>" class="btn btn-light btn-sm"><i class="bi bi-pencil"></i></a>
            <form method="post" action="<?php echo e(route('admin.menus.destroy', $menu)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                <button class="btn btn-light btn-sm text-danger" data-confirm="Hapus menu ini?"><i class="bi bi-trash"></i></button>
            </form>
        </div>
    </div>
    <ol class="menu-list nested-list">
        <?php $__currentLoopData = $menu->childrenRecursive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('admin.menus._item', ['menu' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</li>
<?php /**PATH D:\tester\MAN1Lamsel\resources\views/admin/menus/_item.blade.php ENDPATH**/ ?>