<!doctype html>
<html lang="id">
<head>
    <?php ($loginLogo=\App\Models\Setting::mediaUrl($siteSettings['site_logo']??null,asset('images/logo.svg'))); ?>
    <?php ($loginFavicon=\App\Models\Setting::mediaUrl($siteSettings['site_favicon']??null,asset('images/logo.svg'))); ?>
    <?php ($loginPrimary=\App\Models\Setting::normalizeHex($siteSettings['theme_primary']??'#0877C9')); ?>
    <?php ($loginPrimaryDark=\App\Models\Setting::normalizeHex($siteSettings['theme_primary_dark']??'#045A9D','#045A9D')); ?>
    <?php ($loginAccent=\App\Models\Setting::normalizeHex($siteSettings['theme_accent']??'#F4CD00','#F4CD00')); ?>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login CMS — <?php echo e($siteSettings['site_name'] ?? 'MAN 1 Lampung Selatan'); ?></title>
    <link rel="icon" href="<?php echo e($loginFavicon); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/admin.css')); ?>" rel="stylesheet">
    <style>:root{--brand:<?php echo e($loginPrimary); ?>;--brand-rgb:<?php echo e(\App\Models\Setting::hexToRgb($loginPrimary)); ?>;--brand-dark:<?php echo e($loginPrimaryDark); ?>;--brand-dark-rgb:<?php echo e(\App\Models\Setting::hexToRgb($loginPrimaryDark,'#045A9D')); ?>;--accent:<?php echo e($loginAccent); ?>;--accent-rgb:<?php echo e(\App\Models\Setting::hexToRgb($loginAccent,'#F4CD00')); ?>;}</style>
</head>
<body class="login-page"><div class="login-shell"><div class="login-visual"><div><img src="<?php echo e($loginLogo); ?>" alt="Logo"><span>PORTAL MADRASAH</span><h1>Kelola informasi madrasah bersama-sama.</h1><p>Administrator mengelola seluruh portal, sedangkan guru dan pegawai dapat menulis artikel menggunakan akun manual atau SSO Kemenag.</p></div></div><div class="login-form-wrap"><div class="login-form"><a href="<?php echo e(route('home')); ?>" class="back-link"><i class="bi bi-arrow-left"></i> Kembali ke website</a><h2>Selamat datang</h2><p>Masuk sebagai administrator atau penulis artikel.</p>
<?php if(session('error')): ?><div class="alert alert-danger"><?php echo e(session('error')); ?></div><?php endif; ?>
<?php if($errors->any()): ?><div class="alert alert-danger"><?php echo e($errors->first()); ?></div><?php endif; ?>
<?php if(config('kemenag-sso.enabled')): ?>
<a href="<?php echo e(route('admin.sso.redirect')); ?>" class="btn btn-primary w-100 btn-lg mb-3"><i class="bi bi-shield-lock me-2"></i><?php echo e(config('kemenag-sso.label')); ?></a>
<div class="text-center text-secondary small mb-3">Untuk guru dan pegawai Kementerian Agama</div>
<div class="d-flex align-items-center gap-3 mb-3"><hr class="flex-grow-1"><span class="small text-secondary">LOGIN MANUAL</span><hr class="flex-grow-1"></div>
<?php endif; ?>
<form method="post" action="<?php echo e(route('admin.login.store')); ?>"><?php echo csrf_field(); ?><div class="mb-3"><label class="form-label">Email</label><div class="input-icon"><i class="bi bi-envelope"></i><input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" required autofocus autocomplete="username"></div></div><div class="mb-3"><label class="form-label">Kata Sandi</label><div class="input-icon"><i class="bi bi-lock"></i><input type="password" name="password" class="form-control" required autocomplete="current-password"></div></div><div class="form-check mb-4"><input class="form-check-input" type="checkbox" name="remember" id="remember"><label class="form-check-label" for="remember">Ingat saya</label></div><button class="btn btn-primary w-100 btn-lg">Masuk ke Dashboard <i class="bi bi-arrow-right ms-2"></i></button></form><div class="demo-login"><strong>Login manual penulis</strong><span>Akun dan kata sandi dibuat oleh administrator melalui menu Pengguna & Penulis.</span></div></div></div></div></body></html>
<?php /**PATH D:\tester\MAN1Lamsel\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>