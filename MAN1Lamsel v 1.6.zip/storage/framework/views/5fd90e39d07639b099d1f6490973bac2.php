<?php $__env->startSection('title','Menu Navbar'); ?>
<?php $__env->startSection('page_title','Menu Navbar'); ?>
<?php $__env->startSection('page_subtitle','Susun menu dan submenu dengan drag-and-drop'); ?>
<?php $__env->startSection('page_actions'); ?>
    <a href="<?php echo e(route('admin.menus.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i> Tambah Menu</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row g-4">
    <div class="col-xl-8">
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center gap-3 mb-3">
                <div><h5 class="mb-1">Struktur Navbar</h5><p class="text-secondary small mb-0">Geser ke atas/bawah untuk urutan. Geser ke kanan untuk menjadikannya submenu.</p></div>
                <button type="button" id="saveMenuOrder" class="btn btn-dark"><i class="bi bi-check2-circle me-1"></i> Simpan Urutan</button>
            </div>
            <div id="menuNotice" class="alert d-none"></div>
            <ol class="menu-list root-list" id="menuTree">
                <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('admin.menus._item', ['menu' => $menu], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="empty-menu">Belum ada menu. Klik “Tambah Menu”.</li>
                <?php endif; ?>
            </ol>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="admin-card p-4">
            <h5><i class="bi bi-info-circle me-2"></i>Panduan</h5>
            <ul class="text-secondary small ps-3 mb-0">
                <li class="mb-2">Menu tanpa URL dapat digunakan sebagai induk dropdown.</li>
                <li class="mb-2">URL internal dapat ditulis seperti <code>/berita</code>.</li>
                <li class="mb-2">URL eksternal harus lengkap, misalnya <code>https://...</code>.</li>
                <li>Setelah menggeser struktur, klik <strong>Simpan Urutan</strong>.</li>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>
<script>
(function () {
    document.querySelectorAll('.menu-list').forEach(function (list) {
        new Sortable(list, {
            group: 'nested-menu',
            animation: 180,
            fallbackOnBody: true,
            swapThreshold: 0.65,
            handle: '.drag-handle',
            emptyInsertThreshold: 18
        });
    });

    function serialize(list) {
        return Array.from(list.children).filter(el => el.classList.contains('menu-item')).map(function (item) {
            const childList = Array.from(item.children).find(el => el.classList.contains('menu-list'));
            return {id: Number(item.dataset.id), children: childList ? serialize(childList) : []};
        });
    }

    document.getElementById('saveMenuOrder')?.addEventListener('click', async function () {
        const button = this;
        const notice = document.getElementById('menuNotice');
        button.disabled = true;
        try {
            const response = await fetch(<?php echo json_encode(route('admin.menus.reorder'), 15, 512) ?>, {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content},
                body: JSON.stringify({items: serialize(document.getElementById('menuTree'))})
            });
            const result = await response.json();
            if (!response.ok) throw new Error(result.message || 'Urutan gagal disimpan.');
            notice.className = 'alert alert-success';
            notice.textContent = result.message;
        } catch (error) {
            notice.className = 'alert alert-danger';
            notice.textContent = error.message;
        } finally {
            button.disabled = false;
        }
    });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\tester\MAN1Lamsel\resources\views/admin/menus/index.blade.php ENDPATH**/ ?>