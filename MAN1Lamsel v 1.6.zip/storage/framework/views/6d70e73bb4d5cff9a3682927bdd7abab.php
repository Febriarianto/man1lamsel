<?php $__env->startSection('title','Pengguna'); ?>
<?php $__env->startSection('page_title','Pengguna & Penulis'); ?>
<?php $__env->startSection('page_subtitle','Kelola akun administrator, penulis manual, dan pengguna SSO Kemenag'); ?>
<?php $__env->startSection('page_actions'); ?><a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary"><i class="bi bi-person-plus me-1"></i> Tambah Penulis Manual</a><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(!config('kemenag-sso.enabled')): ?><div class="alert alert-light border"><i class="bi bi-info-circle me-2"></i>Penulis dapat masuk menggunakan akun manual yang dibuat administrator. SSO Kemenag saat ini belum diaktifkan.</div><?php else: ?><div class="alert alert-success"><i class="bi bi-shield-check me-2"></i>Login manual dan SSO Kemenag aktif. Pengguna SSO baru akan dibuat otomatis sebagai <strong>Penulis Artikel</strong> saat login pertama.</div><?php endif; ?>
<div class="admin-card">
    <form class="filter-bar" method="get">
        <input class="form-control" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari nama, email, NIP, atau unit kerja...">
        <select class="form-select" name="role"><option value="">Semua role</option><option value="admin" <?php if(request('role')==='admin'): echo 'selected'; endif; ?>>Administrator</option><option value="author" <?php if(request('role')==='author'): echo 'selected'; endif; ?>>Penulis</option></select>
        <select class="form-select" name="provider"><option value="">Semua login</option><option value="local" <?php if(request('provider')==='local'): echo 'selected'; endif; ?>>Lokal</option><option value="kemenag_sso" <?php if(request('provider')==='kemenag_sso'): echo 'selected'; endif; ?>>SSO Kemenag</option></select>
        <button class="btn btn-dark">Filter</button><a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-light">Reset</a>
    </form>
    <div class="table-responsive"><table class="table align-middle"><thead><tr><th>Pengguna</th><th>Identitas</th><th>Login</th><th>Role</th><th>Status</th><th>Login Terakhir</th><th class="text-end">Aksi</th></tr></thead><tbody>
    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><div class="d-flex align-items-center gap-2"><span class="avatar"><?php echo e(strtoupper(substr($user->name,0,1))); ?></span><div class="table-title"><strong><?php echo e($user->name); ?></strong><small><?php echo e($user->email); ?></small></div></div></td>
        <td><div class="table-title"><strong><?php echo e($user->nip ?: '-'); ?></strong><small><?php echo e($user->unit_name ?: 'Unit belum tersedia'); ?></small></div></td>
        <td><span class="badge bg-light text-dark"><?php echo e($user->auth_provider==='kemenag_sso'?'SSO Kemenag':'Lokal'); ?></span></td>
        <td><?php echo e($user->role==='admin'?'Administrator':'Penulis'); ?></td>
        <td><span class="status-dot <?php echo e($user->active?'published':'draft'); ?>"><?php echo e($user->active?'Aktif':'Nonaktif'); ?></span></td>
        <td><?php echo e(optional($user->last_login_at)->format('d/m/Y H:i') ?: '-'); ?></td>
        <td class="text-end"><a href="<?php echo e(route('admin.users.edit',$user)); ?>" class="btn btn-light btn-sm"><i class="bi bi-pencil"></i></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="7" class="text-center py-5 text-secondary">Belum ada pengguna.</td></tr><?php endif; ?>
    </tbody></table></div><div class="p-3"><?php echo e($users->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\tester\MAN1Lamsel\resources\views/admin/users/index.blade.php ENDPATH**/ ?>