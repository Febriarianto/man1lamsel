<?php
    $children = ($menu->childrenRecursive ?? collect())->where('active', true);
    $hasChildren = $children->isNotEmpty();
    $isTop = ($level ?? 0) === 0;
    $resolved = $menu->resolved_url;
    $path = parse_url($resolved, PHP_URL_PATH);
    $active = $resolved === url()->current() || ($path && $path !== '/' && request()->is(ltrim($path, '/')));
?>
<li class="<?php echo e($isTop ? 'nav-item' : ''); ?> <?php echo e($hasChildren ? ($isTop ? 'dropdown' : 'dropend dropdown-submenu') : ''); ?>">
    <a
        class="<?php echo e($isTop ? 'nav-link' : 'dropdown-item'); ?> <?php echo e($hasChildren ? 'dropdown-toggle' : ''); ?> <?php echo e($active ? 'active' : ''); ?>"
        href="<?php echo e($hasChildren && !$menu->url ? '#' : $resolved); ?>"
        target="<?php echo e($menu->target); ?>"
        <?php if($menu->target === '_blank'): ?> rel="noopener" <?php endif; ?>
        <?php if($hasChildren): ?> data-bs-toggle="dropdown" aria-expanded="false" role="button" <?php endif; ?>
    >
        <?php if($menu->icon): ?><i class="bi <?php echo e($menu->icon); ?> me-1"></i><?php endif; ?>
        <?php echo e($menu->title); ?>

    </a>
    <?php if($hasChildren): ?>
        <ul class="dropdown-menu">
            <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.nav-item', ['menu' => $child, 'level' => ($level ?? 0) + 1], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH D:\tester\MAN1Lamsel\resources\views/partials/nav-item.blade.php ENDPATH**/ ?>