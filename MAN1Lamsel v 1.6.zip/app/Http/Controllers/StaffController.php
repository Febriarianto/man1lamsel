<?php

namespace App\Http\Controllers;

use App\Models\Staff;

class StaffController extends Controller
{
    public function teachers() { return $this->index('teacher'); }
    public function employees() { return $this->index('employee'); }

    public function index(string $type = 'teacher')
    {
        abort_unless(in_array($type, ['teacher', 'employee'], true), 404);
        $staff = Staff::query()->where('active', true)->where('type', $type)->orderBy('sort_order')->orderBy('name')->paginate(16);
        return view('staff.index', compact('staff', 'type'));
    }
}
